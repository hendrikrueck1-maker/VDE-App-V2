/* =========================================================================
   Service Worker der VDE-Prüf-App V2 – Offline-Betrieb.
   Version, Cache-Name und Dateiliste kommen aus js/app-config.js
   (importScripts) – dadurch ist der Worker nachweisbar synchron mit der App.

   Strategie: Precache aller App-Dateien inkl. Icons beim Installieren,
   danach Cache zuerst, Netz nur als Rückfall. Prüfdaten liegen NICHT hier,
   sondern in IndexedDB/localStorage und bleiben bei jedem Cache-Reset erhalten.
   ========================================================================= */
importScripts('js/app-config.js');

/* Ohne diese Dateien ist die App nicht lauffähig → Installation schlägt fehl (alte Version bleibt aktiv).
   Icons sind optional: fehlt eines, funktioniert die App weiter (Platzhalter). */
const OPTIONAL = url => url.startsWith('icons/');

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.all(PRECACHE_DATEIEN.map(async url => {
      try {
        const antwort = await fetch(new Request(url, { cache: 'reload' }));
        if (!antwort.ok) throw new Error(url + ' → HTTP ' + antwort.status);
        await cache.put(new Request(url), antwort);
      } catch (e) {
        if (!OPTIONAL(url)) throw e;
      }
    }));
    /* KEIN skipWaiting: Die neue Version wartet, bis der Nutzer auf der Hauptseite
       „jetzt neu laden" wählt (Nachricht SKIP_WAITING). Erstinstallation aktiviert sich selbst. */
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const namen = await caches.keys();
    await Promise.all(namen.filter(n => n.startsWith(CACHE_PREFIX) && n !== CACHE_NAME).map(n => caches.delete(n)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', event => {
  const d = event.data || {};
  if (d.typ === 'SKIP_WAITING') self.skipWaiting();
  if (d.typ === 'VERSION' && event.source) event.source.postMessage({ typ:'VERSION', appVersion:APP_VERSION, swVersion:SW_VERSION, cache:CACHE_NAME });
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    /* ignoreSearch: index.html?entwurf=… und ähnliche Aufrufe treffen den gleichen Cache-Eintrag */
    const treffer = await caches.match(req, { ignoreSearch: true, cacheName: CACHE_NAME });
    if (treffer) return treffer;
    try {
      return await fetch(req);
    } catch (e) {
      if (req.mode === 'navigate') {
        const start = await caches.match('index.html', { cacheName: CACHE_NAME });
        if (start) return start;
      }
      return Response.error();
    }
  })());
});
